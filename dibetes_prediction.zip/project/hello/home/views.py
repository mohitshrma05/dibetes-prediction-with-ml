from django.shortcuts import render,HttpResponse
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn import svm
from sklearn.metrics import accuracy_score

# Create your views here.
def index(request):
    return render(request, 'index.html')

def predict(request):
    return render(request,'predict.html')

def result(request):
    df = pd.read_csv(r'C:\Users\mohit\Downloads\analysis data\diabetes.csv')
    
    x = df.drop('Outcome', axis=1)
    y = df['Outcome']
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)

    model = svm.SVC(kernel='linear')
    model.fit(x_train, y_train)
    if(request.method=='POST'):
        val1 = float(request.POST['n1'])
        val2 = float(request.POST['n2'])
        val3 = float(request.POST['n3'])
        val4 = float(request.POST['n4'])
        val5 = float(request.POST['n5'])
        val6 = float(request.POST['n6'])
        val7 = float(request.POST['n7'])
        val8 = float(request.POST['n8'])

        input_data = [val1, val2, val3, val4, val5, val6, val7, val8]
        input_data = np.array(input_data).reshape(1,8)

        pred = model.predict(input_data)
        if pred == [1]:
            result1 = 'Positive'
        else:
            result1 = 'Negative'
        print(result1)
        return render(request, 'predict.html', {"result2": result1})
    return render(request, 'predict.html', {"result2": 'Not Predicted Yet'})

